# TODO

- ~~Make a __init__ file to seperate geojson_utils~~
- Test simplify function